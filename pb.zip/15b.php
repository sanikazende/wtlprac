<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you have a database connection
    $conn = mysqli_connect("localhost", "root", "", "15db");

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Escape user inputs for security
    $studentID = mysqli_real_escape_string($conn, $_POST['studentID']);
    $studentName = mysqli_real_escape_string($conn, $_POST['studentName']);
    $emailID = mysqli_real_escape_string($conn, $_POST['emailID']);
    $grade12th = mysqli_real_escape_string($conn, $_POST['12thGrade']);
    $JEEScore = mysqli_real_escape_string($conn, $_POST['JEEScore']);

    // Insert data into the database
    $sql = "INSERT INTO students (studentID, studentName, emailID, 12thGrade, JEEScore) VALUES ('$studentID', '$studentName', '$emailID', '$grade12th', '$JEEScore')";
    
    if (mysqli_query($conn, $sql)) {
        echo "Record added successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
}

// Display the top 5 students based on JEE scores
$conn = mysqli_connect("localhost", "root", "", "15db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM students ORDER BY JEEScore DESC LIMIT 5";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "<h2>Top 5 Students based on JEE Score:</h2>";
    echo "<table border='1'>
            <tr>
                <th>Student ID</th>
                <th>Student Name</th>
                <th>Email ID</th>
                <th>12th Grade</th>
                <th>JEE Score</th>
            </tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>" . $row['studentID'] . "</td>
                <td>" . $row['studentName'] . "</td>
                <td>" . $row['emailID'] . "</td>
                <td>" . $row['12thGrade'] . "</td>
                <td>" . $row['JEEScore'] . "</td>
            </tr>";
    }

    echo "</table>";
} else {
    echo "No records found.";
}

mysqli_close($conn);

?>
