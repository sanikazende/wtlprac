<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array Sorting</title>
    <style>
        table {
            border-collapse: collapse;
            width: 50%;
            margin: 20px;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }
    </style>
</head>
<body>

<h1>Array Sorting</h1>

<?php
// Numeric Array
$numericArray = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5];

// Associative Array
$associativeArray = [
    'apple' => 10,
    'banana' => 5,
    'cherry' => 8,
    'date' => 3,
    'elderberry' => 12
];

// Multidimensional Array
$multidimensionalArray = [
    ['name' => 'John', 'age' => 25],
    ['name' => 'Jane', 'age' => 30],
    ['name' => 'Bob', 'age' => 22],
    ['name' => 'Alice', 'age' => 28]
];

// Sorting Numeric Array
echo "<h2>Numeric Array</h2>";
echo "<p>Original Numeric Array: " . implode(', ', $numericArray) . "</p>";
sort($numericArray);
echo "<p>Sorted Numeric Array (Ascending Order): " . implode(', ', $numericArray) . "</p>";
rsort($numericArray);
echo "<p>Sorted Numeric Array (Descending Order): " . implode(', ', $numericArray) . "</p>";

// Sorting Associative Array
echo "<h2>Associative Array</h2>";
echo "<p>Original Associative Array:</p>";
echo "<pre>";
print_r($associativeArray);
echo "</pre>";

asort($associativeArray);
echo "<p>Sorted Associative Array (Ascending Order by Value):</p>";
echo "<pre>";
print_r($associativeArray);
echo "</pre>";

arsort($associativeArray);
echo "<p>Sorted Associative Array (Descending Order by Value):</p>";
echo "<pre>";
print_r($associativeArray);
echo "</pre>";

ksort($associativeArray);
echo "<p>Sorted Associative Array (Ascending Order by Key):</p>";
echo "<pre>";
print_r($associativeArray);
echo "</pre>";

krsort($associativeArray);
echo "<p>Sorted Associative Array (Descending Order by Key):</p>";
echo "<pre>";
print_r($associativeArray);
echo "</pre>";

// Sorting Multidimensional Array
echo "<h2>Multidimensional Array</h2>";
echo "<p>Original Multidimensional Array:</p>";
echo "<pre>";
print_r($multidimensionalArray);
echo "</pre>";

usort($multidimensionalArray, function($a, $b) {
    return $a['age'] <=> $b['age'];
});
echo "<p>Sorted Multidimensional Array (Ascending Order by Age):</p>";
echo "<pre>";
print_r($multidimensionalArray);
echo "</pre>";

usort($multidimensionalArray, function($a, $b) {
    return $b['age'] <=> $a['age'];
});
echo "<p>Sorted Multidimensional Array (Descending Order by Age):</p>";
echo "<pre>";
print_r($multidimensionalArray);
echo "</pre>";
?>

</body>
</html>
