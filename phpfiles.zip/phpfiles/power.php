<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Power of Four Checker</title>
</head>
<body>

    <h2>Check if a Number is a Power of Four</h2>

    <?php
    function isPowerOfFour($number) {
        // Check if the number is a positive integer
        if (!is_numeric($number) || $number <= 0 || $number != (int)$number) {
            return false;
        }

        // Check if the number is a power of four
        return (($number & ($number - 1)) == 0) && ($number > 0) && ((log($number) / log(4)) % 1 == 0);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Handle form submission

        // Validate input
        $testNumber = $_POST["testNumber"];
        if (!is_numeric($testNumber) || $testNumber <= 0 || $testNumber != (int)$testNumber) {
            echo "<p style='color: red;'>Invalid input. Please enter a valid positive integer.</p>";
        } else {
            // Call the function and display the result
            if (isPowerOfFour($testNumber)) {
                echo "<p>$testNumber is a power of four.</p>";
            } else {
                echo "<p>$testNumber is not a power of four.</p>";
            }
        }
    }
    ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <label for="testNumber">Enter a positive integer:</label>
        <input type="text" name="testNumber" id="testNumber" required>
        <button type="submit">Check Power of Four</button>
    </form>

</body>
</html>
