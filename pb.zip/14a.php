<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Registration Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin-top: 50px;
        }

        .container {
            width: 400px;
            padding: 16px;
            background-color: white;
            margin: 0 auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        input[type=text], input[type=date] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            background-color: #4caf50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Company Registration Form</h2>
        <form action="14.php" method="post">
            <label for="companyID"><b>Company ID</b></label>
            <input type="text" placeholder="Enter Company ID" name="companyID" required>

            <label for="companyName"><b>Company Name</b></label>
            <input type="text" placeholder="Enter Company Name" name="companyName" required>

            <label for="location"><b>Location</b></label>
            <input type="text" placeholder="Enter Location" name="location" required>

            <label for="department"><b>Department</b></label>
            <input type="text" placeholder="Enter Department" name="department" required>

            <label for="registrationDate"><b>Registration Date</b></label>
            <input type="date" name="registrationDate" required>

            <button type="submit">Register Company</button>
        </form>
    </div>
</body>
</html>
