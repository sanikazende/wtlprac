<!DOCTYPE html>
<html>
<head>
    <title>Palindrome Checker</title>
</head>
<body>

<?php
// Function to check if a string is a palindrome
function isPalindrome($str) {
    // Remove spaces and convert to lowercase for a case-insensitive check
    $cleanedStr = strtolower(str_replace(' ', '', $str));

    // Compare the original string with its reverse
    return $cleanedStr === strrev($cleanedStr);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the string from the user input
    $inputString = $_POST["inputString"];

    // Validate if the input is a string
    if (is_string($inputString)) {
        // Check if the string is a palindrome using the isPalindrome function
        $result = isPalindrome($inputString);

        // Display the result
        if ($result) {
            echo "<p>'$inputString' is a palindrome.</p>";
        } else {
            echo "<p>'$inputString' is not a palindrome.</p>";
        }
    } else {
        // If the input is not a string, display an error message
        echo "<p>Please enter a valid string.</p>";
    }
}
?>

<!-- HTML form to take user input -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <label for="inputString">Enter a string:</label>
    <input type="text" name="inputString" id="inputString" required>
    <button type="submit">Check Palindrome</button>
</form>

</body>
</html>
