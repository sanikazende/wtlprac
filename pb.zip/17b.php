<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you have a database connection
    $conn = mysqli_connect("localhost", "root", "", "17db");
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Escape user inputs for security
    $studRollNo = mysqli_real_escape_string($conn, $_POST['studRollNo']);
    $studClass = mysqli_real_escape_string($conn, $_POST['studClass']);
    $studName = mysqli_real_escape_string($conn, $_POST['studName']);
    $studContact = mysqli_real_escape_string($conn, $_POST['studContact']);
    $MentorName = mysqli_real_escape_string($conn, $_POST['MentorName']);
    $issuesDiscussed = mysqli_real_escape_string($conn, $_POST['issuesDiscussed']);

    // Insert data into the database
    $sql = "INSERT INTO Student_Mentor (studRollNo, studClass, studName, studContact, MentorName, issuesDiscussed) VALUES ('$studRollNo', '$studClass', '$studName', '$studContact', '$MentorName', '$issuesDiscussed')";
    
    if (mysqli_query($conn, $sql)) {
        echo "Record added successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
}

// Display records for absent students
$conn = mysqli_connect("localhost", "root", "", "17db");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM Student_Mentor WHERE issuesDiscussed = 'Absent'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "<h2>Records for Absent Students:</h2>";
    echo "<table border='1'>
            <tr>
                <th>Student Roll Number</th>
                <th>Student Class</th>
                <th>Student Name</th>
                <th>Student Contact</th>
                <th>Mentor Name</th>
                <th>Issues Discussed</th>
            </tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>" . $row['studRollNo'] . "</td>
                <td>" . $row['studClass'] . "</td>
                <td>" . $row['studName'] . "</td>
                <td>" . $row['studContact'] . "</td>
                <td>" . $row['MentorName'] . "</td>
                <td>" . $row['issuesDiscussed'] . "</td>
            </tr>";
    }

    echo "</table>";
} else {
    echo "No records found for absent students.";
}

mysqli_close($conn);

?>
