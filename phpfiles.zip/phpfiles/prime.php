<!DOCTYPE html>
<html>
<head>
    <title>Prime Number Checker</title>
</head>
<body>

<?php
// Function to check if a number is prime
function isPrime($number) {
    // 0 and 1 are not prime numbers
    if ($number <= 1) {
        return false;
    }

    // Check for divisors from 2 to the square root of the number
    for ($i = 2; $i <= sqrt($number); $i++) {
        if ($number % $i == 0) {
            // If the number is divisible by any other number, it is not prime
            return false;
        }
    }

    // If no divisors are found, the number is prime
    return true;
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the number from the user input
    $inputNumber = $_POST["number"];

    // Validate if the input is a positive integer
    if (ctype_digit($inputNumber) && $inputNumber > 0) {
        // Check if the number is prime using the isPrime function
        $result = isPrime($inputNumber);

        // Display the result
        if ($result) {
            echo "<p>$inputNumber is a prime number.</p>";
        } else {
            echo "<p>$inputNumber is not a prime number.</p>";
        }
    } else {
        // If the input is not a positive integer, display an error message
        echo "<p>Please enter a valid positive integer.</p>";
    }
}
?>

<!-- HTML form to take user input -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <label for="number">Enter a number:</label>
    <input type="text" name="number" id="number" required>
    <button type="submit">Check Prime</button>
</form>

</body>
</html>
