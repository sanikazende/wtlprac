<!DOCTYPE html>
<html>
<head>
    <title>Design Students Admission Form</title>
</head>
<body>

<h2>Design Students Admission Form</h2>

<form method="post" action="15b.php">
    <label for="studentID">Student ID:</label>
    <input type="text" name="studentID" required><br>

    <label for="studentName">Student Name:</label>
    <input type="text" name="studentName" required><br>

    <label for="emailID">Email ID:</label>
    <input type="email" name="emailID" required><br>

    <label for="12thGrade">12th Grade:</label>
    <input type="text" name="12thGrade" required><br>

    <label for="JEEScore">JEE Score:</label>
    <input type="text" name="JEEScore" required><br>

    <input type="submit" value="Submit">
</form>

</body>
</html>
