<!DOCTYPE html>
<html>
<head>
    <title>Student-Mentor Meeting Record</title>
</head>
<body>

<h2>Student-Mentor Meeting Record</h2>

<form method="post" action="17b.php">
    <label for="studRollNo">Student Roll Number:</label>
    <input type="text" name="studRollNo" required><br>

    <label for="studClass">Student Class:</label>
    <input type="text" name="studClass" required><br>

    <label for="studName">Student Name:</label>
    <input type="text" name="studName" required><br>

    <label for="studContact">Student Contact:</label>
    <input type="text" name="studContact" required><br>

    <label for="MentorName">Mentor Name:</label>
    <input type="text" name="MentorName" required><br>

    <label for="issuesDiscussed">Issues Discussed:</label>
    <textarea name="issuesDiscussed" required></textarea><br>

    <input type="submit" value="Submit">
</form>

</body>
</html>
