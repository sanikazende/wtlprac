<!DOCTYPE html>
<html>
<head>
    <title>Day of the Week</title>
</head>
<body>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the day number from the user input
    $dayNumber = $_POST["dayNumber"];

    // Validate if the input is a number
    if (is_numeric($dayNumber)) {
        // Use switch/case to determine the day based on the number
        switch ($dayNumber) {
            case 1:
                $day = "Monday";
                break;
            case 2:
                $day = "Tuesday";
                break;
            case 3:
                $day = "Wednesday";
                break;
            case 4:
                $day = "Thursday";
                break;
            case 5:
                $day = "Friday";
                break;
            case 6:
                $day = "Saturday";
                break;
            case 7:
                $day = "Sunday";
                break;
            default:
                $day = "Invalid number";
        }

        // Display the result
        echo "<p>Day number: $dayNumber</p>";
        echo "<p>Day of the week: $day</p>";
    } else {
        // If the input is not a number, display an error message
        echo "<p>Please enter a valid number.</p>";
    }
}
?>

<!-- HTML form to take user input -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <label for="dayNumber">Enter a number (1 to 7):</label>
    <input type="text" name="dayNumber" id="dayNumber" required>
    <button type="submit">Show Day</button>
</form>

</body>
</html>
