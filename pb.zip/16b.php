<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you have a database connection
    $conn = mysqli_connect("localhost", "root", "", "16db");

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Escape user inputs for security
    $rollNo = mysqli_real_escape_string($conn, $_POST['rollNo']);
    $studName = mysqli_real_escape_string($conn, $_POST['studName']);
    $studDept = mysqli_real_escape_string($conn, $_POST['studDept']);
    $passingYear = mysqli_real_escape_string($conn, $_POST['passingYear']);
    $classGrades = mysqli_real_escape_string($conn, $_POST['classGrades']);

    // Insert data into the database
    $sql = "INSERT INTO studentsss (rollNo, studName, studDept, passingYear, classGrades) VALUES ('$rollNo', '$studName', '$studDept', '$passingYear', '$classGrades')";
    
    if (mysqli_query($conn, $sql)) {
        echo "Record added successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
}

// Display the appropriate result
$conn = mysqli_connect("localhost", "root", "", "16db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM students";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "<h2>Student Information:</h2>";
    echo "<table border='1'>
            <tr>
                <th>Roll Number</th>
                <th>Student Name</th>
                <th>Department</th>
                <th>Passing Year</th>
                <th>Class Grades</th>
            </tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>" . $row['rollNo'] . "</td>
                <td>" . $row['studName'] . "</td>
                <td>" . $row['studDept'] . "</td>
                <td>" . $row['passingYear'] . "</td>
                <td>" . $row['classGrades'] . "</td>
            </tr>";
    }

    echo "</table>";
} else {
    echo "No records found.";
}

mysqli_close($conn);

?>
