<?php
// Simulate authentication logic
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Validate credentials (this is a basic example, replace with actual authentication logic)
    if ($username === "admin" && $password === "password") {
        // Successful login, display welcome page
        echo "<h1>Welcome, $username!</h1>";
    } else {
        // Invalid credentials, redirect to login page
        header("Location: welcome1.html");
        exit();
    }
} else {
    // If not a POST request, redirect to login page
    header("Location: welcome1.html");
    exit();
}
?>
