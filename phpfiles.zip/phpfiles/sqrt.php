<!DOCTYPE html>
<html>
<head>
    <title>Square Root Calculator</title>
</head>
<body>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the number from the user input
    $inputNumber = $_POST["number"];

    // Validate if the input is a number
    if (is_numeric($inputNumber)) {
        // Calculate the square root using the sqrt function
        $squareRoot = sqrt($inputNumber);

        // Display the result
        echo "<p>Number: $inputNumber</p>";
        echo "<p>Square root: $squareRoot</p>";
    } else {
        // If the input is not a number, display an error message
        echo "<p>Please enter a valid number.</p>";
    }
}
?>

<!-- HTML form to take user input -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <label for="number">Enter a number:</label>
    <input type="text" name="number" id="number" required>
    <button type="submit">Calculate Square Root</button>
</form>

</body>
</html>
