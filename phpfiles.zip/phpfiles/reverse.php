<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reverse Digits</title>
</head>
<body>

    <h2>Reverse Digits of an Integer</h2>

    <?php
    function reverseDigits($number) {
        // Convert the number to a string
        $numberStr = (string)$number;

        // Reverse the string
        $reversedStr = strrev($numberStr);

        // Convert the reversed string back to an integer
        $reversedNumber = (int)$reversedStr;

        return $reversedNumber;
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Handle form submission

        // Validate input
        $originalNumber = $_POST["originalNumber"];
        if (!is_numeric($originalNumber) || strpos($originalNumber, '.') !== false) {
            echo "<p style='color: red;'>Invalid input. Please enter a valid integer.</p>";
        } else {
            // Call the function and display the result
            $reversedNumber = reverseDigits($originalNumber);
            echo "<p>Original Number: $originalNumber</p>";
            echo "<p>Reversed Number: $reversedNumber</p>";
        }
    }
    ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <label for="originalNumber">Enter an integer:</label>
        <input type="text" name="originalNumber" id="originalNumber" required>
        <button type="submit">Reverse Digits</button>
    </form>

</body>
</html>
