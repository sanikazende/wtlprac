<!DOCTYPE html>
<html>
<head>
    <title>Student Information Form</title>
</head>
<body>

<h2>Student Information Form</h2>

<form method="post" action="16.php">
    <label for="rollNo">Roll Number:</label>
    <input type="text" name="rollNo" required><br>

    <label for="studName">Student Name:</label>
    <input type="text" name="studName" required><br>

    <label for="studDept">Department:</label>
    <input type="text" name="studDept" required><br>

    <label for="passingYear">Passing Year:</label>
    <input type="text" name="passingYear" required><br>

    <label for="classGrades">Class Grades (First Class, Second Class, Pass):</label>
    <input type="text" name="classGrades" required><br>

    <input type="submit" value="Submit">
</form>

</body>
</html>
