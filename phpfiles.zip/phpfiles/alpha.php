<!DOCTYPE html>
<html>
<head>
    <title>String Transformations</title>
</head>
<body>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the string from the user input
    $inputString = $_POST["inputString"];

    // Validate if the input is a string
    if (is_string($inputString)) {
        // Transformations
        $uppercase = strtoupper($inputString);
        $lowercase = strtolower($inputString);
        $firstUppercase = ucfirst($inputString);
        $titleCase = ucwords($inputString);

        // Display the results
        echo "<p>Original String: $inputString</p>";
        echo "<p>Uppercase: $uppercase</p>";
        echo "<p>Lowercase: $lowercase</p>";
        echo "<p>First Character Uppercase: $firstUppercase</p>";
        echo "<p>Title Case: $titleCase</p>";
    } else {
        // If the input is not a string, display an error message
        echo "<p>Please enter a valid string.</p>";
    }
}
?>

<!-- HTML form to take user input -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <label for="inputString">Enter a string:</label>
    <input type="text" name="inputString" id="inputString" required>
    <button type="submit">Transform</button>
</form>

</body>
</html>
