<!DOCTYPE html>
<html>

<head>
    <title>Student Grade Checker</title>
</head>

<body>

    <?php
    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the marks from the user input
        $marks = $_POST["marks"];

        // Validate if the input is a number
        if (is_numeric($marks)) {
            // Check the grade based on the given conditions
            if ($marks >= 60) {
                $grade = "First Division";
            } elseif ($marks >= 45 && $marks <= 59) {
                $grade = "Second Division";
            } elseif ($marks >= 33 && $marks <= 44) {
                $grade = "Third Division";
            } else {
                $grade = "Fail";
            }

            // Display the result
            echo "<p>Your marks: $marks%</p>";
            echo "<p>Your grade: $grade</p>";
        } else {
            // If the input is not a number, display an error message
            echo "<p>Please enter valid marks as a number.</p>";
        }
    }
    ?>

    <!-- HTML form to take user input -->
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="marks">Enter your marks:</label>
        <input type="text" name="marks" id="marks" required>
        <button type="submit">Check Grade</button>
    </form>

</body>

</html>