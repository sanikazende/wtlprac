<!DOCTYPE html>
<html>
<head>
    <title>Multiplication Table</title>
</head>
<body>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the number from the user input
    $number = $_POST["number"];

    // Validate if the input is a number
    if (is_numeric($number)) {
        // Print the multiplication table
        echo "<h2>Multiplication Table for $number</h2>";
        echo "<table border='1'>";
        for ($i = 1; $i <= 10; $i++) {
            $result = $number * $i;
            echo "<tr><td>$number x $i</td><td>=</td><td>$result</td></tr>";
        }
        echo "</table>";
    } else {
        // If the input is not a number, display an error message
        echo "<p>Please enter a valid number.</p>";
    }
}
?>

<!-- HTML form to take user input -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <label for="number">Enter a number:</label>
    <input type="text" name="number" id="number" required>
    <button type="submit">Generate Table</button>
</form>

</body>
</html>
