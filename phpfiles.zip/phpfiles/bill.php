<!DOCTYPE html>
<html>
<head>
    <title>Electricity Bill Calculator</title>
</head>
<body>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the units from the user input
    $units = $_POST["units"];

    // Validate if the input is a number
    if (is_numeric($units)) {
        // Calculate the electricity bill based on the provided conditions
        $bill = 0;

        if ($units <= 50) {
            $bill = $units * 3.50;
        } elseif ($units <= 150) {
            $bill = 50 * 3.50 + ($units - 50) * 4.00;
        } elseif ($units <= 250) {
            $bill = 50 * 3.50 + 100 * 4.00 + ($units - 150) * 5.20;
        } else {
            $bill = 50 * 3.50 + 100 * 4.00 + 100 * 5.20 + ($units - 250) * 6.50;
        }

        // Display the result
        echo "<p>Your electricity bill for $units units is: Rs. $bill</p>";
    } else {
        // If the input is not a number, display an error message
        echo "<p>Please enter a valid number of units.</p>";
    }
}
?>

<!-- HTML form to take user input -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <label for="units">Enter the number of units:</label>
    <input type="text" name="units" id="units" required>
    <button type="submit">Calculate Bill</button>
</form>

</body>
</html>
