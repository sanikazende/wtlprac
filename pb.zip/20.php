<?php
// Establish a connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "20db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve user input
$username = $_POST['username'];
$password = $_POST['password'];

// Query the database for the user
$sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
$result = $conn->query($sql);

// Check if the user is authenticated
if ($result->num_rows > 0) {
    // User is authenticated, redirect to the welcome page
    header("Location: 20x.php");
} else {
    // User authentication failed, redirect back to the login page
    header("Location: 20.php");
}

$conn->close();
?>
