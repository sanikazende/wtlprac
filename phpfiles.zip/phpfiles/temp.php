<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Temperature Converter</title>
</head>
<body>

    <h2>Temperature Converter</h2>

    <?php
    function fahrenheitToCelsius($fahrenheit) {
        return ($fahrenheit - 32) * (5/9);
    }

    function celsiusToFahrenheit($celsius) {
        return ($celsius * 9/5) + 32;
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Handle form submission

        // Validate input for Fahrenheit
        $fahrenheit = $_POST["fahrenheit"];
        if (!is_numeric($fahrenheit)) {
            echo "<p style='color: red;'>Invalid input for Fahrenheit. Please enter a numeric value.</p>";
        } else {
            // Convert Fahrenheit to Celsius
            $celsius = fahrenheitToCelsius($fahrenheit);
            echo "<p>$fahrenheit&deg;F is equal to $celsius&deg;C</p>";
        }

        // Validate input for Celsius
        $celsius = $_POST["celsius"];
        if (!is_numeric($celsius)) {
            echo "<p style='color: red;'>Invalid input for Celsius. Please enter a numeric value.</p>";
        } else {
            // Convert Celsius to Fahrenheit
            $fahrenheit = celsiusToFahrenheit($celsius);
            echo "<p>$celsius&deg;C is equal to $fahrenheit&deg;F</p>";
        }
    }
    ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <label for="fahrenheit">Enter temperature in Fahrenheit:</label>
        <input type="text" name="fahrenheit" id="fahrenheit" required>
        <br>

        <label for="celsius">Enter temperature in Celsius:</label>
        <input type="text" name="celsius" id="celsius" required>
        <br>

        <button type="submit">Convert</button>
    </form>

</body>
</html>
