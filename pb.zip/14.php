<?php

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "14db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $companyID = $_POST['companyID'];
    $companyName = $_POST['companyName'];
    $location = $_POST['location'];
    $department = $_POST['department'];
    $registrationDate = $_POST['registrationDate'];

    // Insert the company into the database
    $sql = "INSERT INTO company (companyID, companyName, location, department, registrationDate)
            VALUES ('$companyID', '$companyName', '$location', '$department', '$registrationDate')";

    if ($conn->query($sql) === TRUE) {
        echo "Company registered successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registered Companies</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin-top: 50px;
        }

        .container {
            width: 600px;
            padding: 16px;
            background-color: white;
            margin: 0 auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        input[type=date] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #4caf50;
            color: white;
        }

        button {
            background-color: #4caf50;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Registered Companies</h2>

        <!-- Display Companies Registered Before May 18, 2023 -->
        <table>
            <tr>
                <th>Company ID</th>
                <th>Company Name</th>
                <th>Location</th>
                <th>Department</th>
                <th>Registration Date</th>
            </tr>
            <?php
            // Database connection for displaying registered companies
            $conn_display = new mysqli($servername, $username, $password, $dbname);

            if ($conn_display->connect_error) {
                die("Connection failed: " . $conn_display->connect_error);
            }

            // Display companies registered before May 18, 2023
            $cutoffDate = "2023-05-18";
            $sql_display = "SELECT * FROM companies WHERE registrationDate < '$cutoffDate'";

            $result = $conn_display->query($sql_display);

            if ($result->num_rows > 0) {
                while ($company = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$company['companyID']}</td>
                            <td>{$company['companyName']}</td>
                            <td>{$company['location']}</td>
                            <td>{$company['department']}</td>
                            <td>{$company['registrationDate']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No companies registered before May 18, 2023.</td></tr>";
            }

            // Close the database connection
            $conn_display->close();
            ?>
        </table>
    </div>
</body>
</html>
