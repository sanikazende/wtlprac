<?php

// Numeric Array
$numericArray = [5, 3, 8, 1, 7];
sort($numericArray);
rsort($numericArray);

// Associative Array
$associativeArray = [
    'apple' => 5,
    'banana' => 3,
    'orange' => 8,
    'grape' => 1,
    'kiwi' => 7
];
asort($associativeArray);
arsort($associativeArray);
ksort($associativeArray);
krsort($associativeArray);

// Multidimensional Array
$multidimensionalArray = [
    ['name' => 'John', 'age' => 25],
    ['name' => 'Jane', 'age' => 30],
    ['name' => 'Doe', 'age' => 22]
];
array_multisort(array_column($multidimensionalArray, 'age'), $multidimensionalArray);
array_multisort(array_column($multidimensionalArray, 'age'), SORT_DESC, $multidimensionalArray);

// Output
echo "Numeric Array: " . implode(', ', $numericArray) . "<br>";
echo "Associative Array: " . json_encode($associativeArray) . "<br>";
echo "Multidimensional Array: " . json_encode($multidimensionalArray) . "<br>";

?>
