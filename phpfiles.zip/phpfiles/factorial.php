<!DOCTYPE html>
<html>
<head>
    <title>Factorial Calculator</title>
    <script>
        // JavaScript prompt to take user input
        function getNumber() {
            var number = prompt("Enter a number to find its factorial:");
            // Send the input to the PHP script
            window.location.href = "factorial.php?number=" + number;
        }
    </script>
</head>
<body>

<?php
// PHP script to calculate factorial using recursion
function factorial($n) {
    if ($n == 0 || $n == 1) {
        return 1;
    } else {
        return $n * factorial($n - 1);
    }
}

// Check if the number is provided in the URL
if (isset($_GET["number"])) {
    // Get the number from the URL
    $number = $_GET["number"];

    // Validate if the input is a non-negative integer
    if (ctype_digit($number) && $number >= 0) {
        // Calculate the factorial
        $result = factorial($number);
        echo "<p>Factorial of $number is: $result</p>";
    } else {
        // If the input is not a non-negative integer, display an error message
        echo "<p>Please enter a valid non-negative integer.</p>";
    }
}
?>

<!-- HTML button to trigger the prompt function -->
<button onclick="getNumber()">Calculate Factorial</button>

</body>
</html>
